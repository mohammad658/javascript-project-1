
var photos = ["image/1.jpg", "image/2.jpg", "image/3.jpg", "image/4.jpg", "image/5.jpg", "image/6.jpg", "image/7.jpg",]

var ImgTag=document.querySelector("img")

var count=0

function next () {
    count ++
    if(count>=photos.length){
        count=0
        ImgTag.src=photos[count]

    }else   {ImgTag.src=photos[count]}

    
}

function priv () {
    count --
    if(count<0){
        count=photos.length-1
        ImgTag.src=photos[count]

    }else   {ImgTag.src=photos[count]}

    
}